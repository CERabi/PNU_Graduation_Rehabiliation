import pandas as pd

from keras.models import Sequential, load_model
from keras.layers import LSTM, Dense
from keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split

# data preprocessing
input = pd.read_csv("data.csv", encoding='cp949')
X = input.loc[:, ['A_Ax', 'A_Ay', 'A_Az', 'A_Gx', 'A_Gy', 'A_Gz', 
              'B_Ax', 'B_Ay', 'B_Az', 'B_Gx', 'B_Gy', 'B_Gz']]
y = input.loc[:, ['angle']]
print(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Hyperparameter
l_units_1 = 40
l_units_2 = 40
d_units_1 = 20
d_units_2 = 1
epochs = 1000
batch_size = 1

# LSTM network 생성 및 fit
model = Sequential()
model.add(LSTM(l_units_1, dropout=0.1, input_shape=(12, 1), return_sequences=True))
model.add(LSTM(l_units_2, dropout=0.1))
model.add(Dense(d_units_1, activation='relu'))
model.add(Dense(d_units_2))
model.compile(optimizer='adam', loss='mean_squared_error')
model.summary()

model.fit(X_train, y_train, batch_size, epochs,
          callbacks=EarlyStopping(monitor='loss', patience=100, mode='auto'))

model.save('L40_L40_D20_D1.h5')

model.evaluate(X_test,y_test)
