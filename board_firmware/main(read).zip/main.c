#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "esp_nimble_hci.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "sdkconfig.h"
#include "driver/gpio.h"
#include "imu.h"

/* 장치 이름 */
#define DEVICE_NAME "ESPSensor_B"
char *TAG = DEVICE_NAME;

/* BLE에 필요한 정보들 */
/* service, characteristic uuid(128bit)*/
#define SERVICE_UUID "\xd1\x32\x62\xdf\x06\x7e\xfe\xca\x99\x47\xef\xbe\xa7\x88\x0c\xca"
#define CHARACTERISTIC_READ_UUID "\xcf\x69\x23\xdc\x31\xe6\x11\x87\xf8\x4b\xa1\x87\xb7\xd3\xc0\xde"
#define CHARACTERISTIC_WRITE_UUID "\x3c\x0a\xbc\x05\x5f\xc5\x72\x98\xbc\x45\x02\x79\xb7\xee\xff\xc0"
uint8_t ble_addr_type;
void ble_app_advertise(void);
//char *imu_data_csv = "";        // imu 데이터를 콤마로 구분
//double imu_data[6];
int ble_connected = 0;          // 게이트웨이와 연결 여부

#define BLUE_GPIO 8             // 청색 LED gpio 번호

#define SMPL_RATE_MS 50         // imu 데이터 갱신 시간
#define MAX_FRAME_SIZE 10       // 한 프레임이 담을 개수
uint32_t frameoffset = 0;         // 데이터 수집 순번
uint32_t framenumber = 0;         // 데이터 수집 순번


typedef struct frame{
    uint32_t number;
    float data[MAX_FRAME_SIZE*6];
} frame;

frame imu_data;
frame imu_data_temp;



/* 클라이언트 -> 서버(ESP)로 데이터 write 발생 시 실행*/
static int device_write(uint16_t conn_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    //printf("Data from the client: %.*s\n", ctxt->om->om_len, ctxt->om->om_data);
    if(strcmp((char *)(ctxt->om->om_data),"SYNC") == 0){
        ESP_LOGI(TAG, "(gateway -> esp)sync(reset)");
        framenumber = 0;
        frameoffset = 0;
    }
    return 0;
}

/* 서버 -> 클라이언트(Gateway)로 imu 데이터 전송. 클라이언트에서 읽기 요청시 실행됨 */
static int device_read(uint16_t con_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    //printf("request from client!!!\n");
    //os_mbuf_append(ctxt->om, imu_data_csv, strlen(imu_data_csv));
    os_mbuf_append(ctxt->om, &imu_data, sizeof(imu_data));
    
    return 0;
}

// BLE GATT 서비스 정의
static const struct ble_gatt_svc_def gatt_svcs[] = {
    {.type = BLE_GATT_SVC_TYPE_PRIMARY,
     .uuid = BLE_UUID128_DECLARE(SERVICE_UUID),                 // Define UUID for device type
     .characteristics = (struct ble_gatt_chr_def[]){
         {.uuid = BLE_UUID128_DECLARE(CHARACTERISTIC_READ_UUID),           // Define UUID for reading
          .flags = BLE_GATT_CHR_F_READ,
          .access_cb = device_read},
         {.uuid = BLE_UUID128_DECLARE(CHARACTERISTIC_WRITE_UUID),           // Define UUID for writing
          .flags = BLE_GATT_CHR_F_WRITE,
          .access_cb = device_write},
         {0}}},
    {0}};

// GAP 이벤트 발생에 대한 핸들링
static int ble_gap_event(struct ble_gap_event *event, void *arg)
{
    switch (event->type)
    {
    // Advertise if connected
    case BLE_GAP_EVENT_CONNECT:
        ESP_LOGI("GAP", "BLE GAP EVENT CONNECT %s", event->connect.status == 0 ? "OK!" : "FAILED!");
        if (event->connect.status != 0)
        {
            ble_app_advertise();
        }
        else { // 연결 성공 시
            ble_connected = 1;
        }
        break;
    // Advertise again after completion of the event
    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI("GAP", "BLE GAP EVENT DISCONNECTED");
        ble_app_advertise(); // 연결이 끊어진 경우, 다시 연결을 위해 Advertising 재시작
        ble_connected = 0;
        break;
    case BLE_GAP_EVENT_ADV_COMPLETE:
        ESP_LOGI("GAP", "BLE GAP EVENT(adv complete)");
        ble_app_advertise();
        break;
    default:
        break;
    }
    return 0;
}

// Define the BLE connection
void ble_app_advertise(void)
{
    // GAP - device name definition
    struct ble_hs_adv_fields fields;
    const char *device_name;
    memset(&fields, 0, sizeof(fields));
    device_name = ble_svc_gap_device_name(); // Read the BLE device name
    fields.name = (uint8_t *)device_name;
    fields.name_len = strlen(device_name);
    fields.name_is_complete = 1;
    ble_gap_adv_set_fields(&fields);

    // GAP - device connectivity definition
    struct ble_gap_adv_params adv_params;
    memset(&adv_params, 0, sizeof(adv_params));
    adv_params.conn_mode = BLE_GAP_CONN_MODE_UND; // connectable or non-connectable
    adv_params.disc_mode = BLE_GAP_DISC_MODE_GEN; // discoverable or non-discoverable
    ble_gap_adv_start(ble_addr_type, NULL, BLE_HS_FOREVER, &adv_params, ble_gap_event, NULL);
}

// The application
void ble_app_on_sync(void)
{
    ble_hs_id_infer_auto(0, &ble_addr_type); // Determines the best address type automatically
    ble_app_advertise();                     // Define the BLE connection
}

// The infinite task
void host_task(void *param)
{
    nimble_port_run(); // This function will return only when nimble_port_stop() is executed
}

void app_main()
{
    /* BLE 초기설정 */
    nvs_flash_init();                          // 1 - Initialize NVS flash using
    // esp_nimble_hci_and_controller_init();   // 2 - Initialize ESP controller
    nimble_port_init();                        // 3 - Initialize the host stack
    ble_svc_gap_device_name_set(DEVICE_NAME);  // 4 - Initialize NimBLE configuration - server name
    ble_svc_gap_init();                        // 4 - Initialize NimBLE configuration - gap service
    ble_svc_gatt_init();                       // 4 - Initialize NimBLE configuration - gatt service
    ble_gatts_count_cfg(gatt_svcs);            // 4 - Initialize NimBLE configuration - config gatt services
    ble_gatts_add_svcs(gatt_svcs);             // 4 - Initialize NimBLE configuration - queues gatt services.
    ble_hs_cfg.sync_cb = ble_app_on_sync;      // 5 - Initialize application
    nimble_port_freertos_init(host_task);      // 6 - Run the thread

    /* LED GPIO 설정 */
    gpio_reset_pin(BLUE_GPIO);
    gpio_set_direction(BLUE_GPIO, GPIO_MODE_OUTPUT);

    /* IMU 설정 */
    imu_init();


    /* loop */

    //double imudata[6]; //IMU 값을 담을 실수 배열

    while(true){
        uint8_t blueled = 0;
        while(!ble_connected){
            /* 연결이 이루어지지 않아 Advertising하는 경우, 청색 LED를 계속 점멸*/
            gpio_set_level(BLUE_GPIO,blueled);
            blueled = !blueled;
            vTaskDelay(1000 / portTICK_PERIOD_MS);
        }
        /* 연결 성공 시, 청색 LED 소등 */
        gpio_set_level(BLUE_GPIO, 0);

        while(ble_connected){
            /* 연결되어 있는 동안, imu값을 읽어와 기록 */
            getAccGyro(&imu_data_temp.data[0+6*frameoffset]);
            frameoffset += 1;
            if(frameoffset >= MAX_FRAME_SIZE){
                frameoffset = 0;
                framenumber += 1;
                imu_data_temp.number = framenumber;
                imu_data = imu_data_temp;
                //printf("frame %ld created\n", imu_data.number);
            }
            vTaskDelay(SMPL_RATE_MS / portTICK_PERIOD_MS);
        }
    }

    imu_deinit();
}


            /* imu_data_csv에 기록 */
            //sprintf(imu_data_csv,"%ld,%f,%f,%f,%f,%f,%f",timestamp++,imudata[0],imudata[1],imudata[2],imudata[3],imudata[4],imudata[5]);